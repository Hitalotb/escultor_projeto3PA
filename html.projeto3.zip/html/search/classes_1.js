var searchData=
[
  ['figurageometrica_0',['FiguraGeometrica',['../class_figura_geometrica.html',1,'']]]
];
