var indexSectionsWithContent =
{
  0: "abcdfgimprstvwxyz~",
  1: "cfpsv",
  2: "cfmpsv",
  3: "cdfmpstw~",
  4: "abgirsxyz",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Variáveis",
  5: "Definições e Macros"
};

