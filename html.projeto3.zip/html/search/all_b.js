var searchData=
[
  ['troca_0',['troca',['../sculptor_8cpp.html#a3d7faefa2dabfe41d54e47650592620e',1,'sculptor.cpp']]]
];
