var searchData=
[
  ['g_0',['g',['../class_cut_ellipsoid.html#ad9a2404f3f6a04888334cb87cfeb3a51',1,'CutEllipsoid::g()'],['../class_cut_sphere.html#ab9550e02e3a8e406c080c21c6c07c900',1,'CutSphere::g()'],['../class_cut_voxel.html#a4d0970cf60345c6485804d765feb8cb1',1,'CutVoxel::g()'],['../class_figura_geometrica.html#a51930549bcb90d016b824f10f95df355',1,'FiguraGeometrica::g()'],['../class_put_ellipsoid.html#ad9c02c0b1daeca4232e0f19f06255a51',1,'PutEllipsoid::g()'],['../class_put_voxel.html#a764385a61b8cbbe22c5a385b2eec2623',1,'PutVoxel::g()'],['../struct_voxel.html#a27c0da1ed2ff430401d23ff171612a73',1,'Voxel::g()']]]
];
