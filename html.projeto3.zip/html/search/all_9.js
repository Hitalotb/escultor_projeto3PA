var searchData=
[
  ['r_0',['r',['../class_cut_ellipsoid.html#a8717ff59f0fa3d9cfc1b2fdcc0962cf0',1,'CutEllipsoid::r()'],['../class_cut_sphere.html#a6a717d38c7e58af7799ec3a999cc25ca',1,'CutSphere::r()'],['../class_cut_voxel.html#aea9b3b398ac6f099d70813121a44f686',1,'CutVoxel::r()'],['../class_figura_geometrica.html#a0a4f57efb1a6c525c8aeee34c92e7eab',1,'FiguraGeometrica::r()'],['../class_put_ellipsoid.html#ae759911423fc706908c60f284638a9c8',1,'PutEllipsoid::r()'],['../class_put_voxel.html#ab142ffbb317484f0dc2d54f4c78f1dbe',1,'PutVoxel::r()'],['../struct_voxel.html#a06872ec79b836120b551a848968c0f1b',1,'Voxel::r()']]],
  ['radius_1',['radius',['../class_cut_sphere.html#a1952c3bad1eae06bff6776292381b4ed',1,'CutSphere']]],
  ['rx_2',['rx',['../class_cut_ellipsoid.html#a5d2ee1baae0313b76621fb57c317c2f0',1,'CutEllipsoid::rx()'],['../class_put_ellipsoid.html#a01c481bb5441245c5e8e879681899d56',1,'PutEllipsoid::rx()']]],
  ['ry_3',['ry',['../class_cut_ellipsoid.html#a05d0bb0ec91e61d53d0b952bb8d733f2',1,'CutEllipsoid::ry()'],['../class_put_ellipsoid.html#a4f4274c00346b59e57154b23df712bd4',1,'PutEllipsoid::ry()']]],
  ['rz_4',['rz',['../class_cut_ellipsoid.html#aa47df0d08db6ae887e77b13ef142ade1',1,'CutEllipsoid::rz()'],['../class_put_ellipsoid.html#aaf53d3f0093a1ab471f78da1c24a3606',1,'PutEllipsoid::rz()']]]
];
