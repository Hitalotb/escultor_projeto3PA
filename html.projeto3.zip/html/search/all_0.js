var searchData=
[
  ['a_0',['a',['../class_cut_ellipsoid.html#ac3f9a315c84560ccf8d46dea985e185a',1,'CutEllipsoid::a()'],['../class_cut_sphere.html#aacd38463504d6befba14fe042437f5bd',1,'CutSphere::a()'],['../class_cut_voxel.html#a141ef84d4ee77d39a163a2c7b8d8cfe6',1,'CutVoxel::a()'],['../class_figura_geometrica.html#ae7c8a027fcec3c357265b90458a4d165',1,'FiguraGeometrica::a()'],['../class_put_ellipsoid.html#aa48925e12207b716661df02a15c16296',1,'PutEllipsoid::a()'],['../class_put_voxel.html#a6d28ea593597b57e8b0a40b3a3a3b6ef',1,'PutVoxel::a()'],['../struct_voxel.html#a3ce2579eb0a9f09a07112ce7498a638e',1,'Voxel::a()']]]
];
