var searchData=
[
  ['b_0',['b',['../class_cut_ellipsoid.html#a59861b145d55f52dd790bd819200e009',1,'CutEllipsoid::b()'],['../class_cut_sphere.html#a4caf9c15c1c5f9818b991acdde79e1ff',1,'CutSphere::b()'],['../class_cut_voxel.html#a36eba70545bf0e368af5e561d6cfafa2',1,'CutVoxel::b()'],['../class_figura_geometrica.html#a25e5d6c21410103c25ec55c0117dac0d',1,'FiguraGeometrica::b()'],['../class_put_ellipsoid.html#adfbc6f752055ea68b0301411650206f0',1,'PutEllipsoid::b()'],['../class_put_voxel.html#acc68157667afefff5b26acf96ccf53d0',1,'PutVoxel::b()'],['../struct_voxel.html#a5cd8432b1d7d0fd8b79e0fc7d10373a8',1,'Voxel::b()']]]
];
